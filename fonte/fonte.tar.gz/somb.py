# Botão de som PADRÃO dos sites (o mesmo do site do Mercado Apple):
# pílula escura "♫ Toque pra tocar" -> encolhe para o círculo ♫ -> tocando vira círculo vermelho de pausa.
# Fica no canto de cima, à direita, da animação. Usado por: l24 (build_l24), lotoavenida (la_avenida) e Bolão Loteca (bl_fazer_template).
NOTA = '<svg class="i1" viewBox="0 0 24 24" aria-hidden="true"><path d="M9 3.5v11.1a3.5 3.5 0 1 0 2 3.15V8.2l7-1.75v6.15a3.5 3.5 0 1 0 2 3.15V2z"/></svg>'
PAUSA = '<svg class="i2" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z"/></svg>'
def html(ident="somb", classe="", rotulo=True):
    return ('<button class="somb%s" id="%s" type="button" aria-pressed="false" aria-label="Toque pra tocar o som">%s%s%s</button>'
            % ((" " + classe) if classe else "", ident, NOTA, PAUSA, "<span>Toque pra tocar</span>" if rotulo else ""))
CSS = (
 '.somb{position:absolute;top:12px;right:12px;z-index:3;display:inline-flex;align-items:center;justify-content:center;gap:8px;height:48px;min-width:48px;padding:0 17px 0 13px;'
 'border-radius:24px;border:1.5px solid rgba(255,255,255,.3);background:rgba(24,24,27,.9);color:#fff;font:inherit;font-weight:800;font-size:16px;line-height:1;white-space:nowrap;'
 'cursor:pointer;-webkit-tap-highlight-color:transparent;box-shadow:0 4px 14px rgba(0,0,0,.28)}'
 '.somb svg{width:22px;height:22px;flex:none;fill:currentColor}.somb .i2{display:none}'
 '.somb.min,.somb.on{padding:0;width:48px}.somb.min span,.somb.on span{display:none}'
 '.somb.on{background:#B3261E;border-color:#B3261E}.somb.on .i1{display:none}.somb.on .i2{display:block}'
 '.somb:focus-visible{outline:3px solid #fff;outline-offset:2px;box-shadow:0 0 0 6px #14213D}'
)
# ligaSom(botão, áudio, inicia, ativo): inicia() começa som+animação; ativo() diz se o som em curso é "de verdade" (não o destrave silencioso)
JS = '''function ligaSom(b,au,inicia,ativo){
  if(!b)return;
  function est(t){b.classList.toggle("on",t);if(t)b.classList.add("min");b.setAttribute("aria-pressed",t?"true":"false");b.setAttribute("aria-label",t?"Pausar o som":"Toque pra tocar o som");}
  au.addEventListener("playing",function(){if(ativo())est(true);});
  ["pause","ended"].forEach(function(e){au.addEventListener(e,function(){est(false);});});
  b.addEventListener("click",function(ev){ev.stopPropagation();if(b.classList.contains("on")){try{au.pause();}catch(x){}}else{b.classList.add("min");inicia();}});
  setTimeout(function(){b.classList.add("min");},7000);
}
'''
