# Som da avenida: carro chega, freia, buzina bi-bi, plim do bilhete, acelera e some. (mesmos tempos do la_avenida.py)
import sys, numpy as np, scipy.signal as ss, wave
SR=44100; DUR=8.8; N=int(SR*DUR); t=np.arange(N)/SR; rng=np.random.default_rng(6)
def norm(x): m=np.max(np.abs(x)); return x/m if m>0 else x
def lp(x,f): b,a=ss.butter(2,f/(SR/2)); return ss.lfilter(b,a,x)
def bp(x,lo,hi): b,a=ss.butter(2,[lo/(SR/2),hi/(SR/2)],"band"); return ss.lfilter(b,a,x)
# motor: frequência de explosão e volume ao longo do tempo
f=np.interp(t,[0,.6,1.5,2.2,6.0,6.5,6.9,6.95,7.6,8.6],[230,210,130,85,85,170,290,200,310,330])
a=np.interp(t,[0,.5,1.6,2.3,5.9,6.3,7.2,8.0,8.7],[0.0,.75,.6,.22,.22,.9,.8,.3,0.0])
f=f*(1+.012*np.sin(2*np.pi*11*t))
ph=2*np.pi*np.cumsum(f)/SR
eng=sum(np.sin(k*ph+k)/k**.9 for k in range(1,14))+.6*np.sin(.5*ph)
eng=norm(lp(eng,1900))*(1+.25*np.sin(.5*ph))
vento=norm(bp(rng.standard_normal(N),500,3000))*np.interp(t,[0,.5,2.0,2.3,6.1,7.0,8.6],[0,.5,.15,0,0,.5,0])
mix=.5*norm(eng)*a+.16*vento
def poe(sig,t0,g):
    i=int(t0*SR); j=min(N,i+len(sig)); mix[i:j]+=g*sig[:j-i]
# freada curta
n=int(.32*SR); tt=np.arange(n)/SR
poe(norm(bp(rng.standard_normal(n),1500,4200))*np.sin(np.pi*tt/.32)**2+.3*np.sin(2*np.pi*(1750-500*tt)*tt)*np.sin(np.pi*tt/.32)**2,1.85,.14)
# buzina bi-bi
def buzina(d=.24):
    n=int(d*SR); tt=np.arange(n)/SR; s=np.zeros(n)
    for fr in (415,523):
        for k in (1,2,3,4,5,6): s+=np.sin(2*np.pi*fr*k*tt)/k
    return norm(lp(s,3200))*np.minimum(1,tt/.008)*np.clip((d-tt)/.03,0,1)
poe(buzina(),2.6,.5); poe(buzina(.3),2.95,.5)
# plim do bilhete
def sino(fr,d=.7,tau=.2):
    n=int(d*SR); tt=np.arange(n)/SR
    return (np.sin(2*np.pi*fr*tt)+.4*np.sin(2*np.pi*2*fr*tt)*np.exp(-tt/(tau*.5)))*np.exp(-tt/tau)*np.minimum(1,tt/.003)
for k,fr in enumerate([1318.5,1661.2,1975.5,2637]): poe(sino(fr),3.35+.1*k,.22)
for k,t0 in enumerate([4.1,4.5,4.9]): poe(sino(2637,d=.3,tau=.07),t0,.1)
mix*=np.clip(t/.01,0,1)*np.clip((DUR-t)/.1,0,1)
mix=.9*mix/np.max(np.abs(mix))
with wave.open(sys.argv[1],"wb") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((mix*32767).astype("<i2").tobytes())
print("som ok")
