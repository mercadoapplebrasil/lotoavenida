# Cena da avenida do lotoavenida.com.br: é a MESMA do Loterias 24 Horas (a oficial).
# O desenho vem de l24_avenida.py (carro estacionado com o bilhete do palpite do dia, painel de LED e rotatória)
# e o som é o mesmo avenida.mp3. Aqui ficam só a moldura da seção e o controle (toque, som e palpite do dia).
import shutil, subprocess
SC = "/home/claude/scripts"
subprocess.run(["python3", SC + "/l24_avenida.py"], check=True)
cena = open(SC + "/l24_avenida.svg", encoding="utf-8").read()
# só o cabeçalho do bilhete muda neste site
_a = '<text x="158" y="-200" font-size="21" fill="#fff" text-anchor="middle">LOTERIAS 24 HORAS</text>'
assert _a in cena
cena = cena.replace(_a, '<text x="158" y="-201" font-size="19" fill="#fff" text-anchor="middle">LOTÉRICA DA AVENIDA</text>')
css = """
.desce{display:flex;align-items:center;justify-content:center;gap:10px;min-height:58px;padding:6px 16px;background:#EE7B3D;color:#14213D;font-weight:800;font-size:19px;text-decoration:none}.desce svg{width:26px;height:26px;flex:none;animation:desce 1.2s ease-in-out infinite}.desce:hover{filter:brightness(1.08)}@keyframes desce{0%,100%{transform:translateY(-3px)}50%{transform:translateY(5px)}}@media(prefers-reduced-motion:reduce){.desce svg{animation:none}}
.avn{display:flex;justify-content:center;background:linear-gradient(#E6F0FF 0 75.47%,#D9D2C3 75.47% 79.62%,#9AA3AE 79.62% 80.75%,#3A3F47 80.75%)}
.avn-b{display:block;width:min(100%,700px);margin:0;padding:0;border:0;background:none;cursor:pointer;-webkit-tap-highlight-color:transparent;font:inherit;color:inherit}
.avn-b svg{display:block;width:100%;height:auto}
@media(min-width:760px){.avn-b{width:min(100%,700px,calc(62vh*1.132))}}
"""
js = '''<script>
/* cena da avenida: a mesma do Loterias 24 Horas (toque = som + carro; palpite do dia no bilhete) */
(function(){
"use strict";
var bt=document.getElementById("avn"); if(!bt)return;
var svg=bt.querySelector("svg"), dt=svg.querySelector(".sx-dt");
function mm(q){return !!(window.matchMedia&&window.matchMedia(q).matches);}
if(dt&&mm("(hover: hover) and (pointer: fine)"))dt.textContent="Clique aqui!";
var reduz=mm("(prefers-reduced-motion: reduce)");
var au=new Audio(); au.preload="none"; au.src=bt.getAttribute("data-som");
var liberado=false, somAuto=false, visivel=false, rodando=false, comSomAgora=false, fimT=0, DUR=9000;
function anima(){
  clearTimeout(fimT); svg.classList.remove("show"); void svg.getBoundingClientRect(); svg.classList.add("show"); rodando=true;
  fimT=setTimeout(function(){svg.classList.remove("show");rodando=false;comSomAgora=false;},DUR+150);
}
function tocar(){
  try{au.currentTime=0;}catch(e){}
  var p; try{p=au.play();}catch(e){return Promise.resolve(false);}
  if(!p||!p.then)return Promise.resolve(true);
  return p.then(function(){liberado=true;return true;},function(){return false;});
}
function comSom(){
  var foi=false; comSomAgora=true;
  var t=setTimeout(function(){foi=true;anima();},1200);
  tocar().then(function(ok){
    if(!foi){clearTimeout(t);foi=true;anima();}
    else if(ok){au.pause();}
    if(!ok)comSomAgora=false;
  });
}
bt.addEventListener("click",function(){somAuto=true;comSom();});
function libera(e){
  if(liberado||comSomAgora)return;
  if(e&&e.target&&e.target.closest&&e.target.closest("#avn"))return;
  var p; try{p=au.play();}catch(x){return;}
  if(p&&p.then)p.then(function(){if(!comSomAgora){au.pause();try{au.currentTime=0;}catch(x){}}liberado=true;},function(){});
}
["click","touchend","keydown"].forEach(function(ev){document.addEventListener(ev,libera,true);});
if("IntersectionObserver" in window){
  var arma=function(){setTimeout(function(){new IntersectionObserver(function(es,o){if(es[0].isIntersecting){au.preload="auto";try{au.load();}catch(x){}o.disconnect();}},{rootMargin:"700px"}).observe(bt);},2500);};
  if(document.readyState==="complete")arma();else window.addEventListener("load",arma);
  var primeira=true;
  new IntersectionObserver(function(es){
    visivel=es[0].isIntersecting;
    if(!visivel||rodando||reduz)return;
    var vai=function(){if(!visivel||rodando)return;if(liberado&&!somAuto){somAuto=true;comSom();}else anima();};
    if(primeira){primeira=false;setTimeout(vai,3000);}else vai();
  },{threshold:.6}).observe(bt);
  if(!reduz)setInterval(function(){if(visivel&&!rodando&&!document.hidden)anima();},14000);
}
/* palpite do dia: o mesmo do Loterias 24 Horas (lista "palpites" do dados.json de lá); troca à meia-noite de Brasília */
var PAL=%%PAL%%, diaAtual="";
function hoje(){return new Date(Date.now()-108e5).toISOString().slice(0,10);}
function z(x){return (x<10?"0":"")+x;}
function regra(n){if(n.indexOf(1)>=0)return false;var p=0,l={};n.forEach(function(x){if(x%2===0)p++;var k=Math.floor((x-1)/10);l[k]=(l[k]||0)+1;});if(p!==3)return false;for(var k in l)if(l[k]>2)return false;return true;}
function gera(dia){var s=parseInt(dia.replace(/-/g,""),10)>>>0;function r(){s=(s+0x6D2B79F5)>>>0;var t=s;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;}
  for(var k=0;k<5000;k++){var n=[];while(n.length<6){var v=1+Math.floor(r()*60);if(n.indexOf(v)<0)n.push(v);}n.sort(function(a,b){return a-b;});if(regra(n))return n;}return [7,13,24,33,41,58];}
function aplica(){
  var dia=hoje(); diaAtual=dia;
  var n=(PAL&&PAL[dia])||gera(dia), p=dia.split("-");
  var ts=svg.querySelectorAll(".sx-bola text"); for(var i=0;i<ts.length&&i<6;i++)ts[i].textContent=z(n[i]);
  var pd=svg.querySelector(".sx-pd"); if(pd)pd.textContent="PALPITE DO DIA · "+p[2]+"/"+p[1];
}
window.palpiteDados=function(D){PAL=(D&&D.palpites)||null;aplica();};
aplica();
setInterval(function(){if(diaAtual&&hoje()!==diaAtual)aplica();},30000);
})();
</script>'''
html = ('<style>' + css + '</style>\n<section class="avn" aria-label="Avenida">\n'
        '<button class="avn-b" id="avn" type="button" data-som="avenida.mp3?v=2">' + cena + '</button>\n</section>\n<a class="desce" href="#boloes"><span>Acesse os bolões</span><svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M6 9l6 6 6-6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg></a>\n' + js + '\n')
import json
html = html.replace("%%PAL%%", json.dumps(json.load(open("/home/claude/loterias24horas1/dados.json", encoding="utf-8")).get("palpites") or None, separators=(",", ":")))
open(SC + "/la_avenida.html", "w", encoding="utf-8").write(html)
shutil.copy("/home/claude/loterias24horas1/avenida.mp3", "/home/claude/lotoavenida/avenida.mp3")
print("ok", len(html))
