# Cena da avenida do lotoavenida.com.br: é a MESMA do Loterias 24 Horas (a oficial).
# O desenho vem de l24_avenida.py (carro estacionado com o BILHETE PREMIADO, painel de LED e rotatória),
# o som é o mesmo avenida.mp3 e o controle é o único de somb.py (cena_js). Fica no fim da página, antes do rodapé.
import shutil, subprocess, sys
SC = "/home/claude/scripts"
sys.path.insert(0, SC); import somb
subprocess.run(["python3", SC + "/l24_avenida.py"], check=True)
cena = open(SC + "/l24_avenida.svg", encoding="utf-8").read()
# só o cabeçalho do bilhete muda neste site
_a = '<text x="158" y="-158" font-size="21" fill="#fff" text-anchor="middle">LOTERIAS 24 HORAS</text>'
assert _a in cena
cena = cena.replace(_a, '<text x="158" y="-159" font-size="19" fill="#fff" text-anchor="middle">LOTÉRICA DA AVENIDA</text>')
css = """
.avn{display:flex;justify-content:center;margin-top:34px;background:linear-gradient(#E6F0FF 0 75.47%,#D9D2C3 75.47% 79.62%,#9AA3AE 79.62% 80.75%,#3A3F47 80.75%)}
.avn-in{position:relative;width:min(100%,700px)}
.avn-b{display:block;width:100%;margin:0;padding:0;border:0;background:none;cursor:pointer;-webkit-tap-highlight-color:transparent;font:inherit;color:inherit}
.avn-b svg{display:block;width:100%;height:auto}
@media(min-width:760px){.avn-in{width:min(100%,700px,calc(62vh*1.132))}}
"""
js = '''<script>
/* cena da avenida: a mesma do Loterias 24 Horas; controle único em somb.py (cena_js) */
(function(){
"use strict";
''' + somb.cena_js("avn") + '''})();
</script>'''
html = ('<style>' + somb.CSS + css + '</style>\n<section class="avn" aria-label="Avenida">\n<div class="avn-in">'
        '<button class="avn-b" id="avn" type="button" data-som="avenida.mp3?v=2">' + cena + '</button>' + somb.html() + '</div>\n</section>\n' + js + '\n')
open(SC + "/la_avenida.html", "w", encoding="utf-8").write(html)
shutil.copy("/home/claude/loterias24horas1/avenida.mp3", "/home/claude/lotoavenida/avenida.mp3")
print("ok", len(html))
