# Cena da avenida (lotoavenida.com.br): conversível vermelho entra pela esquerda, DE FRENTE (bico para a direita),
# freia na lotérica, o motorista saca o bilhete PREMIADO, buzina e segue em frente. Som em mp3 (toca mesmo no silencioso).
import math, subprocess
T = 9.0
def P(t): return "%.2f%%" % max(0.0, min(100.0, t / T * 100))
def kf(nome, q):
    return "@keyframes %s{%s}" % (nome, "".join("%s{%s%s}" % (P(x[0]), x[1], (";animation-timing-function:" + x[2]) if len(x) > 2 else "") for x in q))
FREIA, ACELERA = "cubic-bezier(.15,.7,.35,1)", "cubic-bezier(.6,0,.9,.4)"
css = ["""
.avn{padding:34px 0 0}
.avn-d{text-align:center;font-size:16px;font-weight:700;color:#163A8F;margin:0 0 10px}
.avn-b{display:block;width:100%;max-width:760px;margin:0 auto;padding:0;border:0;background:none;cursor:pointer;-webkit-tap-highlight-color:transparent}
.avn-b svg{display:block;width:100%;height:auto}
.avn svg text{font-family:Outfit,Inter,system-ui,sans-serif;font-weight:800}
.av-carro{transform:translateX(-340px)}
.av-roda{transform-box:fill-box;transform-origin:50% 50%}
.av-corpo{transform-origin:150px 100px}
.av-braco{transform-origin:150px 52px;transform:rotate(70deg) scale(.15);opacity:0}
.av-br,.av-bibi,.av-vento,.av-fum{opacity:0}
"""]
reg = []
def anima(sel, nome, q):
    css.append(kf(nome, q)); reg.append(".avn svg.show %s{animation:%s %ss linear both}" % (sel, nome, T))
X = lambda x: "transform:translateX(%spx)" % x
R = lambda a: "transform:rotate(%sdeg)" % a
O = lambda o: "opacity:%s" % o
anima(".av-carro", "av-carro", [(0, X(-340), FREIA), (2.2, X(150)), (6.0, X(150), ACELERA), (7.7, X(660)), (T, X(660))])
anima(".av-roda", "av-roda", [(0, R(0), FREIA), (2.2, R(1260)), (6.0, R(1260), ACELERA), (7.7, R(2700)), (T, R(2700))])
anima(".av-corpo", "av-corpo", [(0, R(0)), (1.7, R(0)), (2.1, R(1.8)), (2.5, R(0)), (6.0, R(0)), (6.25, R(-2)), (6.9, R(0)), (T, R(0))])
anima(".av-vento", "av-vento", [(0, O(1)), (1.5, O(.8)), (2.0, O(0)), (6.2, O(0)), (6.6, O(1)), (T, O(1))])
anima(".av-fum", "av-fum", [(0, O(0)), (5.95, O(0)), (6.1, O(.9)), (6.9, O(.5)), (7.4, O(0)), (T, O(0))])
H = "transform:rotate(70deg) scale(.15);opacity:0"
V = lambda a, s=1: "transform:rotate(%sdeg) scale(%s);opacity:1" % (a, s)
anima(".av-braco", "av-braco", [(0, H), (2.4, H), (2.75, V(-6, 1.08)), (2.95, V(0)), (3.4, V(-9)), (3.8, V(5)), (4.2, V(-9)), (4.6, V(5)),
                                 (5.0, V(0)), (5.55, V(0)), (5.92, H), (T, H)])
q = [(0, O(0)), (2.9, O(0))]; t, on = 2.9, True
while t < 5.3:
    t += .3; q.append((round(t, 2), O(1) if on else O(.25))); on = not on
q += [(5.6, O(0)), (T, O(0))]
anima(".av-br", "av-br", q)
anima(".av-bibi", "av-bibi", [(0, O(0)), (2.55, O(0)), (2.62, O(1)), (3.35, O(1)), (3.55, O(0)), (T, O(0))])
css += reg
css.append("@media (prefers-reduced-motion:reduce){.av-carro{transform:translateX(150px)}.av-braco{transform:none;opacity:1}.av-br{opacity:1}}")

def estrela(cx, cy, Rr=10, r=4.5):
    pts = []
    for k in range(10):
        a = math.radians(-90 + 36 * k); rr = Rr if k % 2 == 0 else r
        pts.append("%.1f %.1f" % (cx + rr * math.cos(a), cy + rr * math.sin(a)))
    return '<path class="av-br" d="M' + "L".join(pts) + 'Z" fill="#F5C842" stroke="#C99A12" stroke-width="1.5"/>'
def roda(cx):
    return ('<g class="av-roda"><circle cx="%d" cy="100" r="20" fill="#151515"/><circle cx="%d" cy="100" r="11" fill="#C9CED6"/>'
            '<path d="M%d 89V111M%d 100H%d" stroke="#7B828C" stroke-width="3"/></g>') % (cx, cx, cx, cx - 11, cx + 11)

carro = ('<g transform="translate(0 180)"><g class="av-carro">'
 '<path class="av-vento" d="M-78 58H-16M-104 76H-30M-66 92H-12" stroke="#fff" stroke-width="5" stroke-linecap="round"/>'
 '<g class="av-fum" fill="#D5D9DF"><circle cx="-4" cy="90" r="9"/><circle cx="-22" cy="82" r="12"/><circle cx="-44" cy="74" r="15"/></g>'
 '<g class="av-corpo">'
 '<path d="M22 66V44" stroke="#7A0D0D" stroke-width="5"/><path d="M2 38H46L42 47H6Z" fill="#9E1515"/>'
 '<path d="M8 92V68C8 62 14 58 24 58H186L262 68C284 71 296 78 296 86V92C296 97 292 100 286 100H18C12 100 8 97 8 92Z" fill="#D21F1F" stroke="#7A0D0D" stroke-width="3"/>'
 '<path d="M186 58L170 32L158 58Z" fill="#9CC3E8" opacity=".75"/><path d="M186 58L170 32" stroke="#23313F" stroke-width="5" stroke-linecap="round"/>'
 '<rect x="112" y="38" width="14" height="22" rx="5" fill="#3B2414"/>'
 '<path d="M132 59c0-11 8-15 16-15s14 4 14 15z" fill="#fff"/>'
 '<circle cx="150" cy="31" r="11" fill="#E0A77A"/><path d="M139 30c-1-12 17-15 22-5c-8-3-14-1-16 6z" fill="#3B2414"/>'
 '<rect x="150" y="27" width="13" height="5" rx="2" fill="#111"/><path d="M152 37q4 3 8 0" fill="none" stroke="#7A3B1E" stroke-width="2" stroke-linecap="round"/>'
 '<path d="M120 61V96M204 63V96" stroke="#7A0D0D" stroke-width="2"/><path d="M20 84H288" stroke="#F5C842" stroke-width="3" stroke-linecap="round"/>'
 '<path d="M282 76l12 5v6h-14z" fill="#FFE9A3"/><rect x="8" y="70" width="6" height="11" rx="2" fill="#FF9A9A"/>'
 + roda(66) + roda(236) +
 '<g class="av-braco">'
 '<path d="M150 52L158 6" stroke="#E0A77A" stroke-width="9" stroke-linecap="round"/>'
 '<g transform="rotate(-5 161 -37)"><rect x="106" y="-76" width="110" height="78" rx="7" fill="#fff" stroke="#0B5F31" stroke-width="3"/>'
 '<path d="M106 -69a7 7 0 0 1 7-7h96a7 7 0 0 1 7 7v15h-110z" fill="#0E7A3E"/>'
 '<text x="161" y="-59" font-size="13" fill="#fff" text-anchor="middle">MEGA-SENA</text>'
 '<text x="161" y="-31" font-size="18" fill="#D21F1F" text-anchor="middle">PREMIADO!</text>'
 '<text x="161" y="-11" font-size="11" fill="#0B3D24" text-anchor="middle">07 13 24 33 41 58</text></g>'
 '<circle cx="158" cy="4" r="7" fill="#E0A77A"/>'
 + estrela(96, -78, 12, 5) + estrela(228, -66, 11, 5) + estrela(226, -6, 9, 4) + estrela(94, -14, 8, 3.5) +
 '</g>'
 '<g class="av-bibi"><rect x="216" y="2" width="84" height="32" rx="16" fill="#fff" stroke="#14213D" stroke-width="2.5"/><path d="M262 34l6 10 4-10z" fill="#fff" stroke="#14213D" stroke-width="2.5" stroke-linejoin="round"/><text x="258" y="24" font-size="17" fill="#14213D" text-anchor="middle">Bi-bi!</text></g>'
 '</g></g></g>')

cena = ('<svg viewBox="0 0 600 330" role="img" aria-label="Cena da avenida: toque para ouvir o carro buzinar com o bilhete premiado" focusable="false" xmlns="http://www.w3.org/2000/svg">'
 '<rect width="600" height="205" fill="#E6F0FF"/><circle cx="545" cy="42" r="24" fill="#FFD766"/>'
 '<rect x="505" y="120" width="10" height="82" fill="#7A5230"/><circle cx="510" cy="104" r="34" fill="#178A47"/><circle cx="534" cy="122" r="22" fill="#1E9E55"/>'
 '<rect x="150" y="40" width="300" height="162" rx="6" fill="#163A8F"/>'
 '<rect x="160" y="50" width="280" height="42" rx="6" fill="#fff"/><text x="300" y="79" font-size="22" fill="#163A8F" text-anchor="middle">LOTÉRICA DA AVENIDA</text>'
 '<path d="M150 100H450V114H150Z" fill="#EE7B3D"/><path d="M150 114H450V120H150Z" fill="#178A47"/>'
 '<rect x="170" y="132" width="84" height="50" rx="4" fill="#DCE4F7"/><rect x="346" y="132" width="84" height="50" rx="4" fill="#DCE4F7"/>'
 '<rect x="272" y="128" width="56" height="74" rx="4" fill="#EAF0FB"/><circle cx="318" cy="166" r="3.5" fill="#163A8F"/>'
 '<rect x="66" y="74" width="7" height="130" fill="#6B7280"/><rect x="6" y="50" width="128" height="34" rx="6" fill="#0E7A3E"/><text x="70" y="73" font-size="15" fill="#fff" text-anchor="middle">Av. 6 de Agosto</text>'
 '<rect y="200" width="600" height="24" fill="#D9D2C3"/><rect y="222" width="600" height="6" fill="#9AA3AE"/>'
 '<rect y="228" width="600" height="102" fill="#3A3F47"/><path d="M0 318H600" stroke="#fff" stroke-width="5" stroke-dasharray="38 28"/>'
 + carro + '</svg>')

js = '''<script>
(function(){
  var sc=document.getElementById("avn"); if(!sc) return; var svg=sc.querySelector("svg");
  var reduz=!!(window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches), rod=false, vis=false, tm=0;
  var au=new Audio(); au.preload="none"; au.src="avenida.mp3";
  function show(){ if(reduz) return; clearTimeout(tm); svg.classList.remove("show"); void svg.getBoundingClientRect(); svg.classList.add("show"); rod=true;
    tm=setTimeout(function(){ svg.classList.remove("show"); rod=false; }, 9100); }
  sc.addEventListener("click",function(){
    var foi=false; function vai(){ if(!foi){ foi=true; show(); } }
    try{ au.currentTime=0; }catch(e){}
    var p=null; try{ p=au.play(); }catch(e){}
    if(p&&p.then){ p.then(vai,vai); setTimeout(vai,900); } else vai();
  });
  if("IntersectionObserver" in window){
    new IntersectionObserver(function(es,o){ if(es[0].isIntersecting){ au.preload="auto"; try{au.load();}catch(e){} o.disconnect(); } },{rootMargin:"600px"}).observe(sc);
    if(!reduz){ new IntersectionObserver(function(es){ vis=es[0].isIntersecting; if(vis&&!rod) show(); },{threshold:.5}).observe(sc);
      setInterval(function(){ if(vis&&!rod&&!document.hidden) show(); },13000); }
  }
})();
</script>'''
html = ('<style>' + "".join(css) + '</style>\n<section class="avn" aria-label="Avenida">\n<p class="avn-d">Toque na avenida para ouvir 🔊</p>\n'
        '<button class="avn-b" id="avn" type="button">' + cena + '</button>\n</section>\n' + js + '\n')
open("/home/claude/scripts/la_avenida.html", "w", encoding="utf-8").write(html)
subprocess.run(["python3", "/home/claude/scripts/la_som_avenida.py", "/tmp/avenida.wav"], check=True)
subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", "/tmp/avenida.wav", "-codec:a", "libmp3lame", "-b:a", "80k", "-ac", "1", "/home/claude/lotoavenida/avenida.mp3"], check=True)
print("ok", len(html))
