# Cena da avenida (lotoavenida.com.br): carro esportivo vermelho chega, para na lotérica,
# o motorista mostra o bilhete PREMIADO, buzina e vai embora. Som no toque.
T = 9.0
def P(t): return f"{max(0.0, min(100.0, t / T * 100)):.2f}%"
def kf(nome, q):
    return "@keyframes %s{%s}" % (nome, "".join(f"{P(x[0])}{{{x[1]}{';animation-timing-function:' + x[2] if len(x) > 2 else ''}}}" for x in q))
FREIA, ACELERA = "cubic-bezier(.15,.7,.35,1)", "cubic-bezier(.6,0,.9,.4)"
css = ["""
.avn{padding:30px 0 0}
.avn-d{text-align:center;font-size:15px;color:#4A5468;margin:0 0 8px}
.avn-b{display:block;width:100%;max-width:1000px;margin:0 auto;padding:0;border:0;background:none;cursor:pointer;-webkit-tap-highlight-color:transparent}
.avn-b svg{display:block;width:100%;height:auto}
.avn svg text{font-family:Outfit,Inter,system-ui,sans-serif;font-weight:800}
.av-carro{transform:translateX(300px)}
.av-roda{transform-box:fill-box;transform-origin:50% 50%}
.av-braco{transform-origin:226px 64px;transform:rotate(80deg) scale(.2);opacity:0}
.av-br,.av-bibi{opacity:0}
"""]
reg = []
def anima(sel, nome, q, fn="linear"):
    css.append(kf(nome, q)); reg.append(f".avn svg.show {sel}{{animation:{nome} {T}s {fn} both}}")
X = lambda x: f"transform:translateX({x}px)"
anima(".av-carro", "av-carro", [(0, X(-420), FREIA), (2.2, X(300)), (6.0, X(300), ACELERA), (7.6, X(1120)), (T, X(1120))])
R = lambda a: f"transform:rotate({a}deg)"
anima(".av-roda", "av-roda", [(0, R(0), FREIA), (2.2, R(1080)), (6.0, R(1080), ACELERA), (7.6, R(2400)), (T, R(2400))])
H, V = "transform:rotate(80deg) scale(.2);opacity:0", lambda a, s=1: f"transform:rotate({a}deg) scale({s});opacity:1"
anima(".av-braco", "av-braco", [(0, H), (2.4, H), (2.7, V(-8, 1.06)), (2.9, V(0)), (3.3, V(-10)), (3.7, V(4)), (4.1, V(-10)), (4.5, V(4)),
                                 (4.9, V(0)), (5.6, V(0)), (5.95, H), (T, H)])
q = [(0, "opacity:0"), (2.8, "opacity:0")]
t, on = 2.8, True
while t < 5.4:
    t += .3; q.append((round(t, 2), "opacity:1" if on else "opacity:.25")); on = not on
q += [(5.6, "opacity:0"), (T, "opacity:0")]
anima(".av-br", "av-br", q)
anima(".av-bibi", "av-bibi", [(0, "opacity:0"), (2.55, "opacity:0"), (2.62, "opacity:1"), (3.4, "opacity:1"), (3.6, "opacity:0"), (T, "opacity:0")])
css += reg
css.append("@media (prefers-reduced-motion:reduce){.av-braco{transform:none;opacity:1}.av-br{opacity:1}}")

def estrela(cx, cy, R=9, r=4):
    import math
    pts = []
    for k in range(10):
        a = math.radians(-90 + 36 * k); rr = R if k % 2 == 0 else r
        pts.append(f"{cx + rr * math.cos(a):.1f} {cy + rr * math.sin(a):.1f}")
    return '<path class="av-br" d="M' + "L".join(pts) + 'Z" fill="#F5C842" stroke="#C99A12" stroke-width="1.5"/>'

carro = f'''<g transform="translate(0 112)"><g class="av-carro">
<path d="M14 100l-8-26h26z" fill="#9E1515"/>
<path d="M10 92C10 78 22 72 40 70L110 62C130 44 160 34 200 34C232 34 252 44 270 60L320 66C338 68 350 76 350 88V98C350 104 346 106 340 106H20C14 106 10 102 10 96Z" fill="#D21F1F" stroke="#7A0D0D" stroke-width="3"/>
<path d="M30 90H340" stroke="#F5C842" stroke-width="4" stroke-linecap="round"/>
<path d="M125 62C142 46 165 40 196 40C222 40 240 48 254 60Z" fill="#23313F"/>
<circle cx="206" cy="54" r="11" fill="#E0A77A"/><path d="M195 51c2-9 18-11 22-1" fill="#3B2414"/><rect x="204" y="49" width="14" height="5" rx="2" fill="#111"/>
<path d="M196 41V61" stroke="#7A0D0D" stroke-width="3"/>
<rect x="334" y="74" width="12" height="7" rx="3" fill="#FFE9A3"/><rect x="12" y="76" width="9" height="7" rx="2" fill="#7A0D0D"/>
<g class="av-roda"><circle cx="85" cy="106" r="22" fill="#151515"/><circle cx="85" cy="106" r="12" fill="#C9CED6"/><path d="M85 94V118M73 106H97" stroke="#7B828C" stroke-width="3"/></g>
<g class="av-roda"><circle cx="275" cy="106" r="22" fill="#151515"/><circle cx="275" cy="106" r="12" fill="#C9CED6"/><path d="M275 94V118M263 106H287" stroke="#7B828C" stroke-width="3"/></g>
<g class="av-braco">
<path d="M226 64L240 24" stroke="#E0A77A" stroke-width="10" stroke-linecap="round"/><circle cx="241" cy="20" r="8" fill="#E0A77A"/>
<g transform="translate(241 14) scale(1.55) translate(-241 -14) rotate(-6 250 -14)"><rect x="214" y="-44" width="74" height="54" rx="6" fill="#fff" stroke="#0B5F31" stroke-width="3"/>
<path d="M214 -38a6 6 0 0 1 6-6h62a6 6 0 0 1 6 6v8h-74z" fill="#0E7A3E"/>
<text x="251" y="-32" font-size="9" fill="#fff" text-anchor="middle">MEGA-SENA</text>
<text x="251" y="-12" font-size="11" fill="#D21F1F" text-anchor="middle">PREMIADO!</text>
<text x="251" y="3" font-size="9" fill="#0B3D24" text-anchor="middle">07 13 24 33 41 58</text></g>
{estrela(196, -70, 11, 5)}{estrela(300, -56, 10, 4.5)}{estrela(296, 16, 8, 3.5)}
</g>
<g class="av-bibi"><rect x="20" y="22" width="92" height="30" rx="15" fill="#fff" stroke="#14213D" stroke-width="2.5"/><text x="66" y="43" font-size="16" fill="#14213D" text-anchor="middle">Bi-bi!</text></g>
</g></g>'''

cena = f'''<svg viewBox="0 0 1000 260" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg">
<rect x="0" y="120" width="1000" height="32" fill="#D9D2C3"/>
<rect x="340" y="0" width="300" height="122" rx="6" fill="#163A8F"/>
<rect x="352" y="10" width="276" height="38" rx="5" fill="#fff"/>
<text x="490" y="37" font-size="22" fill="#163A8F" text-anchor="middle">LOTÉRICA DA AVENIDA</text>
<rect x="368" y="62" width="76" height="44" rx="3" fill="#DCE4F7"/><rect x="536" y="62" width="76" height="44" rx="3" fill="#DCE4F7"/>
<rect x="462" y="58" width="56" height="64" rx="3" fill="#EAF0FB"/><circle cx="508" cy="92" r="3" fill="#163A8F"/>
<rect x="88" y="28" width="7" height="96" fill="#6B7280"/>
<rect x="30" y="6" width="124" height="34" rx="5" fill="#0E7A3E"/><text x="92" y="29" font-size="15" fill="#fff" text-anchor="middle">Av. 6 de Agosto</text>
<rect x="0" y="152" width="1000" height="94" fill="#3A3F47"/><rect x="0" y="150" width="1000" height="6" fill="#9AA3AE"/>
<path d="M0 204H1000" stroke="#fff" stroke-width="5" stroke-dasharray="40 30"/>
{carro}
</svg>'''

js = '''<script>
(function(){
  var sc=document.getElementById("avn"); if(!sc) return; var svg=sc.querySelector("svg");
  var reduz=!!(window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches), rod=false, vis=false, tm=0, C=null;
  function show(){ if(reduz) return; clearTimeout(tm); svg.classList.remove("show"); void svg.getBoundingClientRect(); svg.classList.add("show"); rod=true;
    tm=setTimeout(function(){ svg.classList.remove("show"); rod=false; }, 9100); }
  function env(g,t,pts){ g.gain.setValueAtTime(0.0001,t); pts.forEach(function(p){ g.gain.exponentialRampToValueAtTime(p[1],t+p[0]); }); }
  function som(){ var A=window.AudioContext||window.webkitAudioContext; if(!A) return; if(!C){ try{C=new A();}catch(e){return;} }
    if(C.state==="suspended"){ try{C.resume();}catch(e){} }
    var t=C.currentTime+0.05, o=C.createOscillator(), f=C.createBiquadFilter(), g=C.createGain();
    o.type="sawtooth"; f.type="lowpass"; f.frequency.value=650;
    o.frequency.setValueAtTime(60,t); o.frequency.exponentialRampToValueAtTime(125,t+1.2); o.frequency.exponentialRampToValueAtTime(52,t+2.2);
    o.frequency.setValueAtTime(52,t+6.0); o.frequency.exponentialRampToValueAtTime(175,t+7.4);
    env(g,t,[[0.3,0.12],[2.3,0.045],[5.95,0.045],[6.8,0.14],[8.2,0.0001]]);
    o.connect(f); f.connect(g); g.connect(C.destination); o.start(t); o.stop(t+8.3);
    [2.6,2.95].forEach(function(d){ [415,523].forEach(function(fr){ var b=C.createOscillator(), bf=C.createBiquadFilter(), bg=C.createGain();
      b.type="square"; b.frequency.value=fr; bf.type="lowpass"; bf.frequency.value=1800;
      env(bg,t+d,[[0.02,0.06],[0.2,0.06],[0.26,0.0001]]); b.connect(bf); bf.connect(bg); bg.connect(C.destination); b.start(t+d); b.stop(t+d+0.3); }); });
    [1318.5,1661.2,1975.5].forEach(function(fr,i){ var s=C.createOscillator(), sg=C.createGain(), d=3.2+i*0.09;
      s.frequency.value=fr; env(sg,t+d,[[0.01,0.08],[0.45,0.0001]]); s.connect(sg); sg.connect(C.destination); s.start(t+d); s.stop(t+d+0.5); });
  }
  sc.addEventListener("click",function(){ som(); show(); });
  if(!reduz && "IntersectionObserver" in window){
    new IntersectionObserver(function(es){ vis=es[0].isIntersecting; if(vis&&!rod) show(); },{threshold:.5}).observe(sc);
    setInterval(function(){ if(vis&&!rod&&!document.hidden) show(); },14000);
  }
})();
</script>'''

html = ('<style>' + "".join(css) + '</style>\n<section class="avn" aria-label="Avenida">\n<p class="avn-d">Toque na avenida 🔊</p>\n'
        '<button class="avn-b" id="avn" type="button" aria-label="Cena da avenida: toque para ouvir o carro buzinar com o bilhete premiado">' + cena + '</button>\n</section>\n' + js + '\n')
open("/home/claude/scripts/la_avenida.html", "w", encoding="utf-8").write(html)
print("ok", len(html))
