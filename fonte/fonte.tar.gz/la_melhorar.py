# lotoavenida.com.br: SEO, fontes no próprio site, bolões abertos (do 24 Horas), prêmio da Mega 3092.
import datetime
SRC = "/home/claude/scripts/la_original.html"
DEST = "/home/claude/lotoavenida/index.html"
s = open(SRC, encoding="utf-8").read()
def troca(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:80]); s = s.replace(a, b)

UR = ("U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,"
      "U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD")
fontes = "".join(
    f'@font-face{{font-family:{fam};font-style:normal;font-weight:{w};font-display:swap;src:url(/fonts/{arq}.woff2) format("woff2");unicode-range:{UR}}}\n'
    for fam, w, arq in [("Outfit", 600, "outfit-latin-600-normal"), ("Outfit", 800, "outfit-latin-800-normal"),
                        ("Inter", 400, "inter-latin-400-normal"), ("Inter", 600, "inter-latin-600-normal"),
                        ("Inter", 700, "inter-latin-700-normal")])
LD = ('[{"@context":"https://schema.org","@type":"WebSite","name":"Lotérica da Avenida","url":"https://lotoavenida.com.br/","inLanguage":"pt-BR"},'
      '{"@context":"https://schema.org","@type":"LocalBusiness","name":"Lotérica da Avenida","legalName":"Vilela & Granhani Ltda Me",'
      '"description":"Lotérica credenciada Caixa em Pirassununga/SP: todas as loterias da Caixa, bolões oficiais e conferência de bilhetes.",'
      '"url":"https://lotoavenida.com.br/","image":"https://lotoavenida.com.br/og.png","logo":"https://lotoavenida.com.br/icon-512.png",'
      '"address":{"@type":"PostalAddress","streetAddress":"Av. 6 de Agosto, 14","addressLocality":"Pirassununga","addressRegion":"SP","addressCountry":"BR"},'
      '"openingHoursSpecification":[{"@type":"OpeningHoursSpecification","dayOfWeek":["Monday","Tuesday","Wednesday","Thursday","Friday"],"opens":"08:00","closes":"17:30"},'
      '{"@type":"OpeningHoursSpecification","dayOfWeek":"Saturday","opens":"08:00","closes":"12:00"}],'
      '"hasMap":"https://www.google.com/maps/search/?api=1&query=Av.+6+de+Agosto,+14,+Pirassununga+SP",'
      '"sameAs":["https://www.instagram.com/lotoavenidapirassununga/","https://loterias24horas.com.br/","https://bolaoloteca.com.br/"]}]')

# ---- cabeça ----
troca('<title>Lotérica da Avenida — Pirassununga/SP</title>', '<title>Lotérica da Avenida · Pirassununga/SP | Loterias e bolões da Caixa</title>')
troca('<meta name="description" content="Lotérica da Avenida (Vilela &amp; Granhani), na Av. 6 de Agosto, 14, em Pirassununga/SP. Horário, bolões e palpite da sorte.">',
      '<meta name="description" content="Lotérica da Avenida (Vilela &amp; Granhani), na Av. 6 de Agosto, 14, em Pirassununga/SP. Horário, bolões da Mega-Sena e todas as loterias da Caixa.">')
troca('<meta property="og:description" content="Horário, bolões e palpite da sorte.">',
      '<meta property="og:description" content="Horário, endereço, bolões abertos e todas as loterias da Caixa, em Pirassununga/SP.">')
troca('<meta property="og:image" content="https://lotoavenida.com.br/icon-512.png">',
      '<meta property="og:image" content="https://lotoavenida.com.br/og.png">\n<meta property="og:image:width" content="1200">\n<meta property="og:image:height" content="630">\n<meta name="twitter:card" content="summary_large_image">')
troca('''<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@600;800&family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>
''', '<link rel="preload" href="/fonts/outfit-latin-800-normal.woff2" as="font" type="font/woff2" crossorigin>\n'
     f'<script type="application/ld+json">{LD}</script>\n<style>\n' + fontes)

# ---- estilos ----
troca('.mtag{background:#0E7A3E;color:#fff;border-radius:8px;padding:4px 10px;font-size:15px;letter-spacing:.05em}',
      '.mtag{background:#0E7A3E;color:#fff;border-radius:8px;padding:4px 10px;font-size:15px;letter-spacing:.05em;white-space:nowrap}')
troca('</style>\n</head>', '''.bol .vit{grid-column:1/-1;display:grid;gap:10px}
@media(min-width:760px){.bol .vit{grid-template-columns:repeat(2,minmax(0,1fr))}.bol .vt{grid-column:1/-1}}
.vt{margin:0;font-size:15px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#FFC9A8}
.vi{display:grid;grid-template-columns:1fr auto;gap:2px 12px;align-items:baseline;background:#fff;color:#14213D;border-left:7px solid var(--c,#163A8F);border-radius:14px;padding:14px 16px;text-decoration:none;min-height:56px}
.vi:hover{box-shadow:0 0 0 3px #FFC9A8}
.vi:focus-visible{outline:3px solid #EE7B3D;outline-offset:2px}
.vn{font-weight:700;font-size:19px;line-height:1.25}
.vp{font-family:Outfit,Inter,sans-serif;font-weight:800;font-size:21px;color:var(--c,#163A8F);text-align:right;white-space:nowrap}
.vd{grid-column:1/-1;font-size:16px;color:#4A5468}
@media(max-width:520px){.vi{grid-template-columns:1fr}.vp{text-align:left}}
.bol>div:first-child{grid-column:1/-1;max-width:780px}
.bol>.btns{grid-column:1/-1}
</style>
</head>''')

# ---- bolões abertos dentro do card "Bolão Caixa" ----
troca('''    <div class="mega" id="megaCard" hidden>''', '''    <div class="vit" id="vit" hidden></div>
    <div class="mega" id="megaCard" hidden>''')

# ---- script ----
troca('  var MANUAL={conc:3090,valor:65000000};', '  var MANUAL={conc:3092,valor:82000000};')
vit = open("/home/claude/scripts/vitrine.js", encoding="utf-8").read()
troca('</script>\n</body>', vit + 'vitrine(document.getElementById("vit"), {max:4, titulo:"Bolões abertos agora", aoCarregar:function(D){ if(window.palpiteDados) window.palpiteDados(D); }});\n' + open('/home/claude/scripts/sons.js',encoding='utf-8').read() + open('/home/claude/scripts/sons_la.js',encoding='utf-8').read() + '</script>\n</body>')
troca('<div class="hero"><div class="w">', open("/home/claude/scripts/la_avenida.html", encoding="utf-8").read() + '<div class="hero"><div class="w">')
# o CSS da cena da avenida sobe para o <head> (HTML válido: <style> não fica no <body>)
import re as _re
_b = s.index("<body")
for _m in list(_re.finditer(r"<style>(.*?)</style>", s[_b:], flags=_re.S))[::-1]:
    s = s[:_b + _m.start()] + s[_b + _m.end():]
    s = s.replace("</head>", "<style>" + _m.group(1) + "</style>\n</head>", 1); _b = s.index("<body")
open(DEST, "w", encoding="utf-8").write(s)

hoje = datetime.date.today().isoformat()
open("/home/claude/lotoavenida/sitemap.xml", "w", encoding="utf-8").write(
    '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
    f'  <url><loc>https://lotoavenida.com.br/</loc><lastmod>{hoje}</lastmod><changefreq>weekly</changefreq></url>\n</urlset>\n')
open("/home/claude/lotoavenida/robots.txt", "w", encoding="utf-8").write("User-agent: *\nAllow: /\nDisallow: /fonte/\n\nSitemap: https://lotoavenida.com.br/sitemap.xml\n")
open("/home/claude/lotoavenida/README.md", "w", encoding="utf-8").write("""# Lotérica da Avenida

Site da lotérica: https://lotoavenida.com.br

- Os bolões abertos vêm sozinhos do `dados.json` do Loterias 24 Horas (https://loterias24horas.com.br/dados.json).
- O prêmio da Mega-Sena vem das APIs públicas; se elas atrasarem, vale o `MANUAL` do script (concurso e valor).
- A contagem usa o cronograma da Mega (`CRON` no script).
""")
print("ok", len(s), "bytes")
