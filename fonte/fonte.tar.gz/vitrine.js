/* vitrine: bolões abertos agora, lidos do Loterias 24 Horas */
function vitrine(alvo, opt){
  if(!alvo || !window.fetch) return; opt = opt || {};
  var BASE="https://loterias24horas.com.br/", LOTN={mega:["Mega-Sena","#209869"],quina:["Quina","#5B2A86"],loteca:["Loteca","#C8102E"],milionaria:["+Milionária","#1F2A6B"],dupla:["Dupla Sena","#A6193C"],timemania:["Timemania","#00813C"],lotofacil:["Lotofácil","#930089"]};
  var DIAS=["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"];
  function num(v){ return parseFloat(String(v).replace(/[^\d,]/g,"").replace(",","."))||0; }
  function dd(n){ return (n<10?"0":"")+n; }
  function nb(v){ return String(v).replace("R$ ","R$\u00a0"); }
  function rot(q, loteca){ var l=new Date(new Date(q).getTime()-108e5); return DIAS[l.getUTCDay()]+" "+dd(l.getUTCDate())+"/"+dd(l.getUTCMonth()+1)+(loteca?" · apostas até ":" · sorteio ")+l.getUTCHours()+"h"+(l.getUTCMinutes()?dd(l.getUTCMinutes()):""); }
  function item(href, cor, nome, premio, linha){ var a=document.createElement("a"); a.className="vi"; a.href=href; a.style.setProperty("--c",cor);
    [["vn",nome],["vp",premio||""],["vd",linha]].forEach(function(x){ var s=document.createElement("span"); s.className=x[0]; s.textContent=x[1]; a.appendChild(s); }); return a; }
  fetch(BASE+"dados.json",{cache:"no-store"}).then(function(r){ if(!r.ok) throw 0; return r.json(); }).then(function(D){
    var agora=Date.now(), g={}, ordem=[];
    (D.boloes||[]).forEach(function(b){ if((opt.excluir||[]).indexOf(b.lot)>=0) return; if(new Date(b.quando).getTime()-9e5<=agora) return;
      var k=b.lot+"|"+b.concurso; if(!g[k]){ g[k]=[]; ordem.push(k); } g[k].push(b); });
    ordem.sort(function(a,b){ return new Date(g[a][0].quando)-new Date(g[b][0].quando); });
    var lista=[];
    ordem.slice(0, opt.max||4).forEach(function(k){ var L=g[k], b0=L[0], ab=L.filter(function(b){return b.restam>0;}), LN=LOTN[b0.lot]||[b0.lot,"#0E7A3E"];
      var menor=ab.slice().sort(function(a,b){return num(a.valor)-num(b.valor);})[0];
      var preco = menor ? (ab.length>1?"cota a partir de ":"cota de ")+nb(menor.valor) : "esgotado";
      lista.push(item(BASE+"#b-"+(menor||b0).id, LN[1], (b0.nome||LN[0])+" "+b0.concurso, b0.premio, rot(b0.quando, b0.lot==="loteca")+" · "+preco)); });
    var V=D.virada; if(V && V.boloes && V.boloes.length && opt.virada!==false){
      var vm=V.boloes.filter(function(b){return b.restam>0;}).sort(function(a,b){return num(a.valor)-num(b.valor);})[0];
      if(vm) lista.push(item(BASE+"#virada", "#0E7A3E", "Mega da Virada", V.premio, "Sorteio em 1º/01/2027 · cota a partir de "+nb(vm.valor))); }
    if(!lista.length) return;
    alvo.textContent=""; if(opt.titulo){ var h=document.createElement("p"); h.className="vt"; h.textContent=opt.titulo; alvo.appendChild(h); }
    lista.forEach(function(a){ alvo.appendChild(a); }); alvo.hidden=false;
  }).catch(function(){});
}
