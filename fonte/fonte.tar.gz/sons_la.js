document.addEventListener("click",function(e){ if(!window.SOM) return; var t=e.target;
  if(t.closest&&t.closest("#tbtn")){ SOM.sorteio(6); return; }
  if(t.closest&&t.closest("#mbtn,.mbtn,[aria-expanded]")){ var b=t.closest("#mbtn,.mbtn,[aria-expanded]"); b.getAttribute("aria-expanded")==="true"?SOM.fecha():SOM.abre(); return; }
  if(t.closest&&t.closest(".btn,.vi,.pill,a.ig")) SOM.plim(); },true);
